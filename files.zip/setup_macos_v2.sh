#!/bin/bash

################################################################################
# SETUP RÁPIDO MACOS v2 - BACKUP ICLOUD COM VOLUMES (CORRIGIDO)
# Correções: Melhor detecção de volumes, validação, testes
################################################################################

set -euo pipefail

# CORES
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# BANNER
clear
cat << 'EOF'
╔═══════════════════════════════════════════════════════════════╗
║  🍎 SETUP v2 CORRIGIDO - BACKUP ICLOUD COM VOLUMES           ║
║                                                               ║
║     Setup em < 5 minutos para disco externo                  ║
║                                                               ║
╚═══════════════════════════════════════════════════════════════╝

EOF

# FUNÇÕES
log() {
    echo -e "${BLUE}[*]${NC} $*"
}

success() {
    echo -e "${GREEN}[✓]${NC} $*"
}

error() {
    echo -e "${RED}[✗]${NC} $*"
}

warning() {
    echo -e "${YELLOW}[⚠]${NC} $*"
}

info() {
    echo -e "${CYAN}ℹ${NC} $*"
}

# VERIFICAR SE RODANDO NO MACOS
check_macos() {
    if [[ "$OSTYPE" != "darwin"* ]]; then
        error "Este script é específico para macOS"
        exit 1
    fi
    success "Sistema operacional: macOS"
}

# INSTALAR BREW SE NECESSÁRIO
install_brew() {
    if command -v brew &> /dev/null; then
        success "Homebrew já instalado"
        return 0
    fi
    
    warning "Homebrew não encontrado. Instalando..."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)" || {
        error "Falha ao instalar Homebrew"
        return 1
    }
    success "Homebrew instalado"
}

# INSTALAR DEPENDÊNCIAS MACOS
install_dependencies() {
    log "Instalando dependências..."
    
    # Python 3
    if ! command -v python3 &> /dev/null; then
        log "Instalando Python 3..."
        brew install python3
    else
        success "Python 3 já instalado"
    fi
    
    # icloudpd
    if ! command -v icloudpd &> /dev/null; then
        log "Instalando icloudpd..."
        pip3 install icloudpd
    else
        success "icloudpd já instalado"
    fi
    
    # Pillow
    if ! python3 -c "from PIL import Image" 2>/dev/null; then
        log "Instalando Pillow..."
        pip3 install Pillow
    else
        success "Pillow já instalado"
    fi
    
    # Coreutils
    if ! command -v gsha256sum &> /dev/null; then
        log "Instalando coreutils..."
        brew install coreutils
    else
        success "coreutils já instalado"
    fi
}

# TESTAR INSTALAÇÃO (CORRIGIDO)
test_installation() {
    log "Testando instalação..."
    
    echo ""
    
    # Python
    if python3 -c "import sys; print(f'Python {sys.version.split()[0]}')"; then
        success "Python OK"
    else
        error "Python teste falhou"
    fi
    
    # Pillow
    if python3 -c "from PIL import Image; print('Pillow OK')" 2>&1 | grep -q "OK"; then
        success "Pillow OK"
    else
        warning "Pillow: Pode precisar reinstalar"
        pip3 install --upgrade Pillow
    fi
    
    # icloudpd
    if icloudpd --version 2>&1 | head -1; then
        success "icloudpd OK"
    else
        warning "icloudpd: Pode precisar reinstalar"
        pip3 install --upgrade icloudpd
    fi
    
    echo ""
}

# LISTAR VOLUMES (CORRIGIDO)
list_volumes_correct() {
    echo ""
    echo -e "${CYAN}📱 VOLUMES DISPONÍVEIS:${NC}"
    echo ""
    
    # Usar diskutil para melhor resultado
    local idx=1
    
    # Volume principal sempre primeira opção
    echo -e "${GREEN}${idx}${NC}) Macintosh HD (Disco Principal)"
    local main_size=$(df -h "$HOME" | awk 'NR==2 {print "Total: " $2 " | Disponível: " $4}')
    echo "   $main_size"
    echo ""
    idx=$((idx + 1))
    
    # Listar volumes externos
    for volume in /Volumes/*; do
        # Pular links simbólicos e volumes do sistema
        if [ ! -L "$volume" ] && [ "$volume" != "/Volumes/Macintosh HD" ] && [ "$volume" != "/Volumes/Recovery" ]; then
            local name=$(basename "$volume")
            local space=$(df -h "$volume" 2>/dev/null | awk 'NR==2 {print "Total: " $2 " | Disponível: " $4}' || echo "N/A")
            
            echo -e "${GREEN}${idx}${NC}) $name"
            echo "   $space"
            echo ""
            idx=$((idx + 1))
        fi
    done
}

# SELECIONAR VOLUME (CORRIGIDO)
select_volume_correct() {
    log "Selecionando volume de destino..."
    
    list_volumes_correct
    
    # Contar volumes reais
    local volume_count=1  # Contar volume principal
    for volume in /Volumes/*; do
        if [ ! -L "$volume" ] && [ "$volume" != "/Volumes/Macintosh HD" ] && [ "$volume" != "/Volumes/Recovery" ]; then
            volume_count=$((volume_count + 1))
        fi
    done
    
    read -p "Qual volume deseja usar? (1-$volume_count): " choice
    
    if [ -z "$choice" ] || ! [[ "$choice" =~ ^[0-9]+$ ]]; then
        error "Opção inválida"
        exit 1
    fi
    
    # Processar seleção
    local idx=1
    
    # Opção 1: Volume principal
    if [ "$choice" = "1" ]; then
        echo "$HOME"
        return 0
    fi
    
    idx=$((idx + 1))
    
    # Opções 2+: Volumes externos
    for volume in /Volumes/*; do
        if [ ! -L "$volume" ] && [ "$volume" != "/Volumes/Macintosh HD" ] && [ "$volume" != "/Volumes/Recovery" ]; then
            if [ "$idx" = "$choice" ]; then
                echo "$volume"
                return 0
            fi
            idx=$((idx + 1))
        fi
    done
    
    error "Opção inválida"
    exit 1
}

# VALIDAR DISCO (MELHORADO)
validate_disk() {
    local disk_path="$1"
    
    log "Validando disco: $disk_path"
    
    # Verificar se existe
    if [ ! -d "$disk_path" ]; then
        error "Diretório não encontrado: $disk_path"
        return 1
    fi
    
    # Verificar permissões
    if [ ! -w "$disk_path" ]; then
        warning "Sem permissão de escrita em: $disk_path"
        warning "Tentando contornar com sudo..."
        
        # Tentar criar diretório teste
        if ! mkdir -p "$disk_path/.test_write_permission" 2>/dev/null; then
            error "Sem permissão. Tente:"
            echo "   sudo chmod 755 '$disk_path'"
            return 1
        else
            rm -rf "$disk_path/.test_write_permission"
        fi
    fi
    
    # Verificar espaço
    local available=$(df "$disk_path" 2>/dev/null | awk 'NR==2 {print $4}' | awk '{print $1 * 1024}' || echo "0")
    local available_gb=$((available / 1024 / 1024))
    
    if [ "$available_gb" -lt 50 ]; then
        warning "Espaço baixo! Disponível: ${available_gb}GB (Recomendado: 100GB+)"
        read -p "Continuar mesmo assim? (s/N): " cont
        if [[ "$cont" != "s" ]]; then
            return 1
        fi
    else
        success "Espaço suficiente: ${available_gb}GB disponível"
    fi
    
    return 0
}

# CRIAR ESTRUTURA
create_structure() {
    local disk_path="$1"
    
    log "Criando estrutura de diretórios..."
    
    mkdir -p "$disk_path/icloud_backups"/{downloads,archive,duplicates,logs,reports,temp,cleanup_backups}
    
    chmod 750 "$disk_path/icloud_backups"
    chmod 755 "$disk_path/icloud_backups"/{downloads,archive,logs,reports}
    chmod 700 "$disk_path/icloud_backups"/{duplicates,temp,cleanup_backups}
    
    success "Estrutura criada em: $disk_path/icloud_backups"
}

# COPIAR SCRIPTS
copy_scripts() {
    log "Copiando scripts..."
    
    mkdir -p ~/.local/bin
    
    # Scripts locais
    local script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    
    for script in backup_icloud_macos.sh duplicate_detector.py safe_cleanup.sh volume_manager.sh backup_monitor.sh backup_automation.sh backup_manager.sh; do
        if [ -f "$script_dir/$script" ]; then
            cp "$script_dir/$script" ~/.local/bin/ 2>/dev/null || true
            chmod +x ~/.local/bin/"$script" 2>/dev/null || true
        fi
    done
    
    success "Scripts copiados para ~/.local/bin"
}

# CRIAR CONFIG
create_config() {
    local disk_path="$1"
    local config_file="$HOME/.icloudpd_volume_config"
    
    cat > "$config_file" << EOF
#!/bin/bash
# Configuração de Volume para Backup iCloud
# Gerado: $(date)

export BACKUP_VOLUME="$disk_path"
export BACKUP_ROOT="\$BACKUP_VOLUME/icloud_backups"
export ICLOUD_USERNAME=""

EOF

    success "Configuração salva: $config_file"
}

# CRIAR ATALHOS
create_aliases() {
    log "Criando atalhos..."
    
    local shell_rc=""
    
    # Detectar shell
    if [ -f "$HOME/.zshrc" ]; then
        shell_rc="$HOME/.zshrc"
    elif [ -f "$HOME/.bash_profile" ]; then
        shell_rc="$HOME/.bash_profile"
    else
        shell_rc="$HOME/.bashrc"
    fi
    
    # Checar se já existem
    if ! grep -q "alias icloud-backup" "$shell_rc" 2>/dev/null; then
        cat >> "$shell_rc" << 'EOF'

# Atalhos do Sistema de Backup iCloud
alias icloud-backup='backup_icloud_macos.sh'
alias icloud-analyze='python3 duplicate_detector.py'
alias icloud-cleanup='safe_cleanup.sh'
alias icloud-volumes='volume_manager.sh'
alias icloud-monitor='backup_monitor.sh'

EOF
    fi
    
    success "Atalhos criados em: $shell_rc"
}

# RESUMO
show_summary() {
    local disk_path="$1"
    
    echo ""
    echo -e "${GREEN}════════════════════════════════════════════════════════════${NC}"
    echo -e "${GREEN}✓ SETUP COMPLETADO COM SUCESSO!${NC}"
    echo -e "${GREEN}════════════════════════════════════════════════════════════${NC}"
    echo ""
    
    echo "📁 Configuração:"
    echo "   Volume: $disk_path"
    echo "   Backup em: $disk_path/icloud_backups"
    echo ""
    
    echo "🚀 Próximos Passos:"
    echo ""
    echo "1. Recarregar Terminal:"
    echo "   ${CYAN}source ~/.zshrc${NC}"
    echo ""
    echo "2. Fazer backup:"
    echo "   ${CYAN}icloud-backup${NC}"
    echo ""
    echo "3. Monitorar progresso (em outro terminal):"
    echo "   ${CYAN}backup_monitor.sh --summary${NC}"
    echo ""
    echo "4. Analisar duplicatas:"
    echo "   ${CYAN}icloud-analyze ~/icloud_backups/downloads/\$(date +%Y-%m-%d)${NC}"
    echo ""
    
    echo "📖 Documentação:"
    echo "   GUIA_MACOS_VOLUMES.md"
    echo "   README.md"
    echo ""
}

# MAIN
main() {
    check_macos
    echo ""
    
    install_brew
    echo ""
    
    install_dependencies
    echo ""
    
    test_installation
    
    # Selecionar volume CORRIGIDO
    local selected_volume=$(select_volume_correct)
    
    if [ -z "$selected_volume" ]; then
        error "Nenhum volume selecionado"
        exit 1
    fi
    
    echo ""
    success "Volume selecionado: $selected_volume"
    echo ""
    
    # Validar
    if ! validate_disk "$selected_volume"; then
        error "Validação do disco falhou"
        exit 1
    fi
    echo ""
    
    # Criar estrutura
    create_structure "$selected_volume"
    echo ""
    
    # Copiar scripts
    copy_scripts
    echo ""
    
    # Criar config
    create_config "$selected_volume"
    echo ""
    
    # Criar atalhos
    create_aliases
    echo ""
    
    # Resumo
    show_summary "$selected_volume"
}

# Executar
main "$@"
